#!/usr/bin/env python3
"""Revision 2: exact integer bounds, cut signatures and bit-free inverse replay."""
import json, random, math
from pathlib import Path
from itertools import combinations
from collections import Counter
import verify_switches as v
counts=Counter()
def bounds(row):
    d,G,D=row['d'],row['G'],row['D'];n=len(d);assert G*G<=D
    if sum(d)%2:return False
    P=math.prod(max(1,min(a,n-1-a)) for a in d)
    assert D**3<=2**(2*n)*(G*G*P)**3,(d,G,D)
    if 'D_even' in row:assert D**3<=2**(2*n)*row['D_even']**3
    if min(d)>0:
        M=sum(d)//2;assert D**2*n**(3*n)<=G**4*(2*n+M)**(3*n)
    return True

def reach(vertices,E,start):
    adj={i:set() for i in vertices}
    for a,b in E:adj[a].add(b);adj[b].add(a)
    seen={start};st=[start]
    while st:
        for b in adj[st.pop()]-seen:seen.add(b);st.append(b)
    return seen

def cut_check(n,E):
    if len(reach(range(n),E,0))!=n:return False
    E=sorted(E);T=[];seen={0}
    while len(seen)<n:
        a,b=next((a,b) for a,b in E if (a in seen)!=(b in seen));seen.update((a,b));T.append((a,b))
    tree=[[] for _ in range(n)]
    for e in T:
        a,b=e;tree[a].append((b,e));tree[b].append((a,e))
    sig={e:0 for e in E}
    for i,e in enumerate(e for e in E if e not in T):
        a,b=e;st=[(a,[])];visited={a}
        while st:
            x,p=st.pop()
            if x==b:break
            for y,f in tree[x]:
                if y not in visited:visited.add(y);st.append((y,p+[f]))
        for f in p+[e]:sig[f]|=1<<i
    C=Counter(sig.values());assert sum(x-1 for x in C.values())<=n-1
    marked=set()
    for S in range(1,(1<<n)-1,2):
        cut=tuple(e for e in E if ((S>>e[0])^(S>>e[1]))&1)
        if len(cut)==2:
            assert sig[cut[0]]==sig[cut[1]];marked.add(cut)
    assert len(marked)<=sum(math.comb(x,2) for x in C.values())<=math.comb(n,2)
    return True
orig=v.repair
def checked(n,A):
    R,marks,_=orig(n,A);B=set(R);comps=dict(v.comp_arcs(n,v.oriented(R)))
    for S,((a,e),(c,b)),kind in marks:
        C=comps[S];rem=C-{(a,e),(c,b)};assert len(C)-len(rem)==2
        L=reach(S,rem,a);V=reach(S,rem,c)
        assert b in L and e in V and L.isdisjoint(V) and L|V==S and min(len(L),len(V))>=3
        typ=int((a,b) in B and (b,a) in B)
        assert typ==int((c,e) in B and (e,c) in B)==kind
        if typ:rm={(b,a),(e,c)};ad={(b,c),(e,a)}
        else:rm={(a,e),(c,b)};ad={(a,b),(c,e)}
        assert rm<=B and not ad&B;B=(B-rm)|ad;counts['bit_free_marks']+=1
    assert B==set(A)
    f=math.prod(1+math.comb(len(S),2) for S in comps if len(S)>=6);assert f**3<=2**(2*n)
    counts['switch_replay']+=1
    return R,marks,f
if __name__=='__main__':
    for g in json.loads(Path('counts.json').read_text()):
        for row in g['sorted_degree_table']:
            if bounds(row):counts['archived_even_degree_vectors']+=1
    for row in json.loads(Path('dp_replay.json').read_text()):
        if bounds(row):counts['direct_DP_even_vectors']+=1
    for s in range(6,2001):assert (1+math.comb(s,2))**3<=2**(2*s)
    counts['scalar_sizes']=1995
    for n in range(2,7):
        E=list(combinations(range(n),2))
        for mask in range(1<<len(E)):
            F=[e for i,e in enumerate(E) if mask>>i&1]
            if n==6:
                d=Counter(x for e in F for x in e)
                if any(d[i]%2 for i in range(n)):continue
            if cut_check(n,F):counts['exhaustive_connected_graphs']+=1
    rng=random.Random(451126)
    for i in range(200):
        n=rng.randrange(6,13);p=rng.random();E=[e for e in combinations(range(n),2) if rng.random()<p or e[1]==e[0]+1]
        assert cut_check(n,E);counts['seeded_connected_graphs']+=1
    v.repair=checked;e=v.exhaustive();s=v.seeded()
    result={'checks':dict(counts),'exhaustive_replay':e,'seeded_replay':s,'note':'Degree counts and switches replay archived inputs; cut graph checks and scalar sizes newly generated.'}
    Path('robustness_results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));print('REVISION2_ROBUSTNESS_PASS')
