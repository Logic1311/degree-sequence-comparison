#!/usr/bin/env python3
"""Check last-exit construction against exact local transition enumeration.
Use all small directed Eulerian orientations through n=5 plus seeded examples.
"""
from itertools import combinations, permutations, product
from collections import Counter
from math import factorial,prod
from pathlib import Path
import json,random
from verify_switches import comp_arcs, degs, cycle


def transitions(V,E):
    I={v:sorted(e for e in E if e[1]==v) for v in V};O={v:sorted(e for e in E if e[0]==v) for v in V}
    assert all(len(I[v])==len(O[v])>0 for v in V)
    start=min(E);r=start[0];c={v:len(O[v]) for v in V}
    # BFS on reversed arcs, tree points toward root.
    distance={r:0};queue=[r]
    for v in queue:
        for x,y in I[v]:
            if x not in distance:distance[x]=distance[v]+1;queue.append(x)
    assert set(distance)==V
    tree={v:min(e for e in O[v] if distance[e[1]]==distance[v]-1) for v in V if v!=r}
    choices=[]
    for v in sorted(V):
        fixed=start if v==r else tree[v]
        choices.append([((fixed,)+p if v==r else p+(fixed,)) for p in permutations(e for e in O[v] if e!=fixed)])
    constructed=set()
    for lists in product(*choices):
        order=dict(zip(sorted(V),lists));used=Counter();cur=r;tour=[]
        while used[cur]<len(order[cur]):
            e=order[cur][used[cur]];used[cur]+=1;cur=e[1];tour.append(e)
        assert cur==r and set(tour)==E and len(tour)==len(E)
        T=tuple(sorted(zip(tour,tour[1:]+tour[:1])));assert T not in constructed;constructed.add(T)
    assert len(constructed)==prod(factorial(c[v]-1) for v in V)
    # Enumerate all local bijections independently. Also count directed trees by direct choices.
    nsys=prod(factorial(c[v]) for v in V)
    accepted=set(); all_even=0
    for target_lists in product(*(permutations(O[v]) for v in sorted(V))):
        T={e:f for v,targets in zip(sorted(V),target_lists) for e,f in zip(I[v],targets)}
        unseen=set(E);lengths=[]
        while unseen:
            e0=min(unseen);e=e0;length=0
            while e in unseen:
                unseen.remove(e);e=T[e];length+=1
            assert e==e0;lengths.append(length)
        if all(l%2==0 for l in lengths):all_even+=1
        if len(lengths)==1:accepted.add(tuple(sorted(T.items())))
    assert constructed<=accepted
    tau=0
    W=sorted(V-{r})
    for A in product(*(O[v] for v in W)):
        T={v:e[1] for v,e in zip(W,A)};good=True
        for x in W:
            for _ in range(len(V)):
                if x==r:break
                x=T[x]
            if x!=r:good=False;break
        tau+=good
    assert tau>=1 and len(accepted)==tau*len(constructed)
    if len(E)%2==0:
        assert all_even>=len(accepted) and all_even*prod(c.values())>=nsys
    else:assert all_even==0
    return len(constructed),len(accepted),nsys,tau


def small():
    stats=Counter();seen=set()
    for n in range(2,6):
        edges=list(combinations(range(n),2))
        for m in range(1,1<<len(edges)):
            d=[0]*n;U=[]
            for i,(a,b) in enumerate(edges):
                if m>>i&1:d[a]+=1;d[b]+=1;U.append((a,b))
            if any(v%2 for v in d):continue
            if any(x==0 for x in d):continue # connected components on their own vertex set
            for mask in range(1<<len(U)):
                E={e if mask>>i&1 else e[::-1] for i,e in enumerate(U)}
                out,inc=degs(n,E)
                if out!=inc or len(comp_arcs(n,E))!=1:continue
                ans=transitions(set(range(n)),E);stats['oriented_components']+=1
                stats['last_exit_tours']+=ans[0];stats['all_euler_tours']+=ans[1];stats['local_systems']+=ans[2]
    return dict(stats)


def seeded():
    rng=random.Random(17105);stats=Counter();seen=set()
    while stats['oriented_components']<250:
        n=rng.randrange(6,10);V=list(range(n));rng.shuffle(V);E=cycle(V)
        for _ in range(20):
            k=rng.randrange(3,n+1);w=rng.sample(V,k);C=cycle(w)
            if not any(e in E or e[::-1] in E for e in C):E|=C
            if prod(factorial(x) for x in degs(n,E)[0])>8000:break
        if prod(factorial(x) for x in degs(n,E)[0])>8000 or (n,frozenset(E)) in seen:continue
        seen.add((n,frozenset(E)));ans=transitions(set(range(n)),E)
        stats['oriented_components']+=1;stats['last_exit_tours']+=ans[0];stats['all_euler_tours']+=ans[1];stats['local_systems']+=ans[2]
    return dict(stats)

if __name__=='__main__':
    res={'exhaustive_small':small(),'seeded_larger':seeded()}
    Path('tour_results.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2));print('LAST_EXIT_AND_BEST_PASS')
