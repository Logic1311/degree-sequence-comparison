#!/usr/bin/env python3
"""Independent direct adjacency-matrix enumeration by dynamic programming.
No support decomposition or repair logic is used. Exact integers throughout.
"""
from functools import lru_cache
from itertools import combinations
from math import prod
from pathlib import Path
import json, random

@lru_cache(None)
def G(d):
    if not d:return 1
    if any(a<0 or a>=len(d) for a in d) or sum(d)%2:return 0
    if d[-1]==0:return 1
    k=d[-1]; tail=d[:-1]
    result=0
    for S in combinations([i for i,a in enumerate(tail) if a>0],k):
        S=set(S);result+=G(tuple(sorted(x-(i in S) for i,x in enumerate(tail))))
    return result


def D(d):
    n=len(d)
    @lru_cache(None)
    def count(i,c):
        if i==n:return int(not any(c))
        if any(x>n-i-(j>=i) for j,x in enumerate(c)):return 0
        if sum(c)!=sum(d[i:]):return 0
        avail=[j for j in range(n) if j!=i and c[j]>0]
        mandatory={j for j in avail if c[j]==n-i-(j>=i)}
        if d[i]<len(mandatory):return 0
        total=0
        for S in combinations([j for j in avail if j not in mandatory],d[i]-len(mandatory)):
            chosen=mandatory|set(S); total+=count(i+1,tuple(x-(j in chosen) for j,x in enumerate(c)))
        return total
    return count(0,tuple(d))


def check(d):
    n=len(d);g=G(tuple(sorted(d)));dd=D(tuple(d));P=prod(max(1,min(x,n-1-x)) for x in d)
    assert g*g<=dd
    if sum(d)%2==0:
        assert dd<=4**n*P*g*g
        if all(d):assert dd*n**(2*n)<=g*g*(2*n+sum(d)//2)**(2*n)
    return g,dd

if __name__=='__main__':
    data=json.loads(Path('counts.json').read_text()); replay=[]
    for record in data:
        for row in record['sorted_degree_table']:
            d=tuple(row['d']);g,dd=check(d); assert (g,dd)==(row['G'],row['D']), (d,g,dd,row)
            replay.append({'d':d,'G':g,'D':dd})
    nbase=len(replay)
    rng=random.Random(20261126)
    for n in (7,8):
        cases={(r,)*n for r in range(n)}
        for j in range(36):
            d=[0]*n; p=(j%9+1)/10
            for a,b in combinations(range(n),2):
                if rng.random()<p:d[a]+=1;d[b]+=1
            cases.add(tuple(sorted(d)))
        for d in sorted(cases):
            g,dd=check(d);replay.append({'d':d,'G':g,'D':dd})
    Path('dp_replay.json').write_text(json.dumps(replay,indent=2)+'\n')
    print('INDEPENDENT_DP_PASS', 'replayed_sorted_degree_vectors',nbase,'new_sorted_degree_vectors',len(replay)-nbase)
