#!/usr/bin/env python3
"""Exact exhaustive small-n counts using underlying oriented supports.
All graphs labelled, loopless; digraphs may have antiparallel arcs.
No random sampling or floating arithmetic in this file.
"""
from collections import Counter
from itertools import combinations
from math import prod
import json
from pathlib import Path


def components(n, edges):
    adj=[[] for _ in range(n)]
    for a,b in edges: adj[a].append(b); adj[b].append(a)
    unseen={i for i in range(n) if adj[i]}; comps=[]
    while unseen:
        v=min(unseen); seen={v}; stack=[v]
        while stack:
            for x in adj[stack.pop()]:
                if x not in seen: seen.add(x); stack.append(x)
        unseen-=seen
        comps.append((seen, sum(len(adj[x]) for x in seen)//2))
    return comps


def degree_counts(n):
    edges=list(combinations(range(n),2)); N=1<<len(edges)
    # Ordinary graph count independent of oriented-support decomposition.
    degrees=[(0,)*n]*N; G=Counter()
    for mask in range(N):
        if mask:
            b=mask&-mask; a,c=edges[b.bit_length()-1]
            d=list(degrees[mask^b]);d[a]+=1;d[c]+=1;degrees[mask]=tuple(d)
        G[degrees[mask]]+=1
    D=Counter(); De=Counter(); G2=Counter(); support_checks=0; even_supports=0
    orientations_examined=0; half_masks_examined=0; support_H_cases=0
    for u, deg in enumerate(degrees):
        if any(x%2 for x in deg):continue
        c=tuple(x//2 for x in deg)
        selected=[e for j,e in enumerate(edges) if u>>j&1]
        comps=components(n, selected)
        is_even=all(l%2==0 for _,l in comps)
        if is_even: even_supports+=1
        E=F=0
        # EO and half-factors count via different per-edge contribution rules.
        for mask in range(1<<len(selected)):
            out=[0]*n; red=[0]*n
            for j,(a,b) in enumerate(selected):
                if mask>>j&1:
                    out[a]+=1;red[a]+=1;red[b]+=1
                else:out[b]+=1
            E+=tuple(out)==c
            F+=tuple(red)==c
        orientations_examined+=1<<len(selected);half_masks_examined+=1<<len(selected)
        assert E>0 and F<=E,(n,u,E,F)
        assert (F>0)==is_even,(n,u,E,F)
        if is_even: assert E<=F*prod(max(1,x) for x in c),(n,u,E,F)
        support_checks+=1
        # An antiparallel pair contributes one degree on each endpoint.
        rem=(N-1)^u; h=rem
        while True:
            d=tuple(a+b for a,b in zip(c,degrees[h]))
            D[d]+=E;G2[d]+=F
            if is_even:De[d]+=E
            support_H_cases+=1
            if h==0: break
            h=(h-1)&rem
    assert all(G2[d]==G[d]**2 for d in set(G2)|set(G))
    even_degree_vectors=positive_degree_vectors=0; odd_vectors=0
    for d in set(G)|set(D):
        assert G[d]**2<=D[d]
        if sum(d)%2:
            assert G[d]==0
            odd_vectors+=1
            continue
        assert G[d]>0 if D[d]>0 else G[d]==0
        P=prod(max(1,min(x,n-1-x)) for x in d)
        assert De[d]<=P*G[d]**2
        assert D[d]<=4**n*De[d]
        assert D[d]<=4**n*P*G[d]**2
        assert G[d]==G[tuple(n-1-x for x in d)]
        assert D[d]==D[tuple(n-1-x for x in d)]
        even_degree_vectors+=1
        if all(d):
            M=sum(d)//2
            assert D[d]*n**(2*n)<=G[d]**2*(2*n+M)**(2*n)
            positive_degree_vectors+=1
    # A compact list of sorted degree vectors for independent directed DP replay.
    table=[{'d':list(d),'G':G[d],'D':D[d],'D_even':De[d]} for d in sorted(set(G)|set(D)) if tuple(sorted(d))==d]
    return dict(n=n,all_labelled_graphs=N,even_degree_supports=support_checks,all_even_component_supports=even_supports,
        orientation_candidates=orientations_examined,half_factor_candidates=half_masks_examined,support_H_cases=support_H_cases,
        graphical_labelled_vectors=len(G),even_total_vectors=even_degree_vectors,positive_even_vectors=positive_degree_vectors,
        odd_total_digraphical_vectors=odd_vectors,balanced_digraphs=sum(D.values()),even_component_digraphs=sum(De.values()),
        all_graph_pairs=sum(G2.values()),sorted_degree_table=table)

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--max-n',type=int,default=6);args=ap.parse_args()
    out=[]
    for n in range(1,args.max_n+1):
        r=degree_counts(n);out.append(r);print(json.dumps({k:v for k,v in r.items() if k!='sorted_degree_table'}),flush=True)
    Path('counts.json').write_text(json.dumps(out,indent=2)+'\n');print('EXHAUSTIVE_COUNT_PASS')
