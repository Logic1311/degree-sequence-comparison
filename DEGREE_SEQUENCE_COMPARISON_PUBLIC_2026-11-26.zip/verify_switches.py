#!/usr/bin/env python3
"""Exercise the componentwise parity repair and its explicit inverse.
Exhaustive two-triangle case plus seeded disjoint Eulerian supports.
"""
from itertools import combinations, product
from collections import Counter
from pathlib import Path
import random,json


def pair(a,b):return tuple(sorted((a,b)))
def oriented(A):return {e for e in A if e[::-1] not in A}
def degs(n,A):
    out=[0]*n; inc=[0]*n
    for a,b in A:
        assert a!=b; out[a]+=1;inc[b]+=1
    return tuple(out),tuple(inc)
def comp_arcs(n,O):
    adj=[set() for _ in range(n)]
    for a,b in O:adj[a].add(b);adj[b].add(a)
    unseen={v for v in range(n) if adj[v]}; result=[]
    while unseen:
        v=min(unseen); S={v}; st=[v]
        while st:
            for w in adj[st.pop()]-S:S.add(w);st.append(w)
        unseen-=S
        result.append((frozenset(S),frozenset((a,b) for a,b in O if a in S)))
    return result

def repair(n,A):
    A=set(A);before=set(A);d=degs(n,A);assert d[0]==d[1] and sum(d[0])%2==0
    old=comp_arcs(n,oriented(A)); odd=[c for c in old if len(c[1])%2];assert len(odd)%2==0
    marks=[]
    for (S,P),(T,Q) in zip(odd[::2],odd[1::2]):
        compatible=[]
        for (a,b),(c,e) in product(sorted(P),sorted(Q)):
            assert all(((x,y) in A)==((y,x) in A) for x,y in ((a,e),(b,c)))
            if ((a,e) in A)==((b,c) in A):compatible.append((a,b,c,e,int((a,e) in A)))
        assert compatible,'no compatible pair'
        a,b,c,e,kind=compatible[0]
        if kind==0:
            remove={(a,b),(c,e)};add={(a,e),(c,b)}
        else:
            remove={(b,c),(e,a)};add={(b,a),(e,c)}
        assert remove<=A and not add&A and len({a,b,c,e})==4
        A=(A-remove)|add
        assert degs(n,A)==d
        expected=(P|Q)-{(a,b),(c,e)}|{(a,e),(c,b)}
        assert (S|T,expected) in comp_arcs(n,oriented(A))
        marks.append((S|T,tuple(sorted(((a,e),(c,b)))),kind))
    final=comp_arcs(n,oriented(A));assert all(len(E)%2==0 for _,E in final)
    # Decode independently from output components and local marks.
    markmap={S:(cross,kind) for S,cross,kind in marks}; assert len(markmap)==len(marks)
    B=set(A); fiber_bound=1
    for S,C in final:
        v=len(S); m=len(C)
        if v>=6:
            fiber_bound*=1+m*(m-1)
            assert 1+m*(m-1)<=v**4<=4**v
        if S not in markmap:continue
        assert v>=6
        ((a,e),(c,b)),kind=markmap[S]
        assert {(a,e),(c,b)}<=C
        if not kind:rm={(a,e),(c,b)};ad={(a,b),(c,e)}
        else:rm={(b,a),(e,c)};ad={(b,c),(e,a)}
        assert rm<=B and not ad&B
        B=(B-rm)|ad
    assert B==before and fiber_bound<=4**n
    return frozenset(A), tuple(marks),fiber_bound

def cycle(V):return set(zip(V,V[1:]+V[:1]))

def exhaustive():
    n=6;seen=set();fibers=Counter();stats=Counter();bounds={}
    for S in combinations(range(n),3):
        if 0 not in S:continue
        T=tuple(i for i in range(n) if i not in S)
        C1=cycle(list(S));C2=cycle(list(T));cross=list(product(S,T))
        for o1,o2 in product([0,1],repeat=2):
            O={e if not o1 else e[::-1] for e in C1}|{e if not o2 else e[::-1] for e in C2}
            for mask in range(1<<len(cross)):
                A=O|{e for i,uv in enumerate(cross) if mask>>i&1 for e in (uv,uv[::-1])}
                R,marks,bound=repair(n,A)
                assert (R,marks) not in seen;seen.add((R,marks));fibers[R]+=1;bounds[R]=bound
                stats['instances']+=1;stats['full_switches' if marks[0][2] else 'empty_switches']+=1
    assert all(fibers[R]<=bounds[R] for R in fibers)
    stats['distinct_outputs']=len(fibers);stats['max_observed_fiber']=max(fibers.values())
    return dict(stats)

def seeded():
    rng=random.Random(1052026); stats=Counter()
    for t in range(1500):
        # Even number of odd circuits; at least one test includes many odd pairs.
        n_odd=2*(t%5);n_even=(t//5)%4
        sizes=[rng.choice([3,5,7,9]) for _ in range(n_odd)]+[rng.choice([4,6,8,10]) for _ in range(n_even)]
        if not sizes:sizes=[4]
        n=sum(sizes)+(t%3);vertices=list(range(n));rng.shuffle(vertices);O=set();idx=0
        for k in sizes:
            block=vertices[idx:idx+k];idx+=k;O|=cycle(block)
            # Add 0--3 directed quadrilaterals using only new unordered pairs.
            for _ in range(25):
                if len(block)<4:break
                V=rng.sample(block,4);C=cycle(V)
                if not any(e in O or e[::-1] in O for e in C) and rng.random()<.4: O|=C
        p=[0,.12,.5,.88,1][t%5];A=O|{e for a,b in combinations(range(n),2) if (a,b) not in O and (b,a) not in O and rng.random()<p for e in ((a,b),(b,a))}
        R,marks,_=repair(n,A);stats['instances']+=1;stats['merged_pairs']+=len(marks)
        stats['full_switches']+=sum(k for _,_,k in marks);stats['empty_switches']+=sum(1-k for _,_,k in marks)
        stats['largest_n']=max(stats['largest_n'],n);stats['max_pairs']=max(stats['max_pairs'],len(marks))
    return dict(stats)

if __name__=='__main__':
    r={'exhaustive_disjoint_triangles':exhaustive(),'seeded_composites':seeded()}
    Path('switch_results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));print('SWITCH_ROUNDTRIP_PASS')
